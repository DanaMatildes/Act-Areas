package package5;

public class Circulo5 {
	
	public float radio;
	
	public Circulo5 (float radio){
		this.radio = radio;
	}
	
	public Circulo5() {
		this(177800);
	}
	
	public double calculaArea(float radio) {
		return Math.PI*radio*radio;
	}
	
	public double calculaCircunferencia(float radio) {
		return Math.PI*radio*2;
	}


}


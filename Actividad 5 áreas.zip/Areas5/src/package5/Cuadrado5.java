package package5;

public class Cuadrado5 {
	
	public float lado;

	public Cuadrado5(long lado) {   
		this.lado = lado;
	}
	
	public Cuadrado5() {
		this(177800);
	}
	
	
	public float calculaArea(float lado) {
		return lado*lado;
	}
	
	public float calculaPerim(float lado) {
		return lado*4;
	}
	
	public double calculaDiag(float lado) {
		return Math.sqrt(2*lado*lado);
	}

}

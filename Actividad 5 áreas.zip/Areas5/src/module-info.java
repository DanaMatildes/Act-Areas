/**
 * 
 */
/**
 * @author 52733
 *
 */
module Areas5 {
}